#include "map.hpp"
#include "food.hpp"

int main(int argc, char** argv) {
    // TODO Kreativaufgabe
}
